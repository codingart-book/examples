# Making sense of touch and sensors

In this chapter, we continue with p5.js and explore different interaction possibilities for the web: from multi-touch to using sensors of a mobile device. Note that the examples in this chapter are made for multi-touch and sensor-equipped devices such as smart phones, tablets and laptops with touch screens.
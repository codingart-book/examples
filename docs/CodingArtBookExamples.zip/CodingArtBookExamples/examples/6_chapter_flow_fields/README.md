# Flow fields and particle storms

In this chapter, we move to p5.js, the Processing for the web. We start with a gentle introduction of p5.js and its key differences to Processing. Then, we move into a series of explorative case around generative art and flow fields.
# Completion and production

In this chapter, we describe the fourth step of our process and show you how to produce your work with Processing. The main point in this chapter is that Processing can support you all the way from idea to production and there are only a few tricks to know. 
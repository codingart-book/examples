# Intermission: MOUNTROTHKO

In this chapter, we show how the four steps can be combined in a realistic project.
# Refinement and depth

In this chapter, we describe the third step of our process and show how to bring randomness into our creative work. The main point behind this chapter is not just creative exploration of randomness and noise, we also show you how to compute data that you need in a structured way.
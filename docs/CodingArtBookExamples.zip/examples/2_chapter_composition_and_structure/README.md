# Composition and structure

In this chapter, we describe the second step of our process and show you how to work with structure--in code and visually. The main point behind this chapter is dealing with (necessary) complexity and how to get 'unstuck'.
# Idea to visuals

In this chapter, we describe the first step of our process and also introduce the very basics of Processing. We explain basic visual elements, how the Processing canvas works, animation tricks and how to use interaction. The main point behind this chapter is to follow a creative process and express early ideas directly in code.